# Source reconciliation overview (v1)

This folder documents how RDM Datalab validates its curated **ABS + QCEW** benchmarks against the authoritative sources.

## Why this exists

These reconciliations provide evidence that the ETL/ELT logic is not distorting the source data:
- When the pipeline says “San Francisco County NAICS 42 receipts in year X”, it should match the Census API.
- When the pipeline says “San Francisco County NAICS 42 QCEW employment/wages in year X”, it should match BLS annual-average releases.

## What was implemented

### ABS reconciliation (Census API)
- Unit of comparison: **county × NAICS2 × year**
- Facts compared (additive): `FIRMPDEMP`, `EMP`, `PAYANN`, `RCPPDEMP`
- Matching rules:
  - Firms & employment: **exact match**
  - Payroll & receipts: **tolerance ± $1,000** (to account for rounding / integer conversions)

### QCEW reconciliation (BLS annual averages)
- Unit of comparison: **county × NAICS2 × year**
- Facts compared (additive): employment, total wages
- Matching rules:
  - Employment & total wages: **exact match**
  - (If any derived wage fields are checked: allow small tolerance, e.g., ±$1 on avg wage)

### Orchestration
- Unified runner to generate:
  - a combined CSV (row-level comparisons + pass/fail)
  - a markdown summary suitable for GitHub logs

## Latest run (example)
Command:
`python -m qa.reconciliation --systems abs qcew --years 2022 2023 --counties 06075 06085 --naics 42 62 --outdir artifacts/qa --publish_bq false`

Results:
- ABS: pass_all 8/8
- QCEW: pass_all 8/8
- No suppressed/missing notes in this slice.

## Next expansions recommended
- Add **one state-wide reconciliation slice** (state-level rollups) to catch county coverage issues.
- Add **national totals reconciliation** vs:
  - Census “first look” tables / published totals
  - BLS QCEW national totals
- Persist reconciliation artifacts under:
  - `artifacts/qa/reconciliation/YYYYMMDD/`
