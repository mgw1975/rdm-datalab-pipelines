# Known issues & interpretation notes (v1)

This note is intended for **end users** of the data product and for internal troubleshooting.

## 1) ABS vs QCEW are different programs and will not align perfectly

Even when both datasets are “correct,” you should expect differences because:
- **ABS** is company/firm-based and uses Census frames + admin sources and survey content.
- **QCEW** is establishment-based and comes from UI tax records and related admin processing.

ABS itself notes that receipts/payroll/employment values are derived from administrative sources and may not be directly comparable to other surveys. (See Census ABS methodology pages.)

## 2) ABS year naming: collection year vs reference year

The ABS uses the **collection year** in the survey name, while the data refer to a **reference year**.
Example from Census: “The 2024 ABS covers reference year 2023.”

In the Census API, this often results in the **API vintage** being aligned to the **reference year**.

Implication: always treat `year_num` as the **reference year of economic activity**, not when the survey was collected.

## 3) The observed 2022→2023 ABS declines (firms/employment/receipts)

In RDM Datalab’s current national snapshot, ABS totals appear to fall materially from 2022 to 2023,
while QCEW totals rise.

This can happen for several reasons:

### A) A real economic shift (least likely at this magnitude)
A large, broad decline across nearly all counties and many sectors is unusual for 2022→2023.

### B) Comparability breaks / methodology revisions (plausible)
ABS methodology explicitly cautions about comparability and notes that several core figures are derived
from administrative sources and evaluated against other programs. A change in sources, edits, or frames
could shift published totals.

### C) A pipeline scope mismatch (very plausible)
National totals can be wrong even when county-level spot checks pass if the pipeline is:
- filtering out legitimate rows (e.g., certain industries or “total” rows),
- using a parameter combination that excludes part of the universe,
- or missing a required dimension (e.g., a “YEAR” variable or total-industry row).

**Action**: see `docs/qa/abs_anomaly_investigation_playbook.md` for the next checks.

## 4) Guidance for dashboard users

Until the anomaly is fully understood:
- Prefer **within-year** comparisons (county vs national in the same year) over multi-year ABS trends.
- For time trends, consider using **QCEW** as the primary time-series signal for employment/wages.
- Use ABS for structure/ownership/demographic cross-sections and for cross-sectional benchmarking.

